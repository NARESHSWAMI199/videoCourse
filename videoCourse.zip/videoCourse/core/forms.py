from django import forms
from django_countries.fields import CountryField
from django_countries.widgets import CountrySelectWidget

payment = (
    ('S' , "stripe"),
    ('P' , 'paypal')
)


class CheckoutForm(forms.Form):
    name = forms.CharField( widget = forms.TextInput)
    street_address = forms.CharField(max_length=30 , widget = forms.TextInput)
    zip_code = forms.CharField( widget = forms.TextInput)
    country = CountryField (blank_label = '(select country)').formfield(
        required =False,
        widget=CountrySelectWidget(attrs = {
       'class': 'custom-select d-block w-100',
       'name' : 'country'
    }))




