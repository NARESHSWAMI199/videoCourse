from django.db import models
from django.shortcuts import reverse
from django.conf import settings
from django_countries.fields import CountryField


CATEGORY_CHOICES = (
    ('P' , 'python'),
    ('J' , 'java'),
    ('K' ,  'kotlin'),
)




class Videos(models.Model):
    slug = models.SlugField(unique=True)
    title = models.CharField(max_length =100)
    time = models.DateTimeField()
    Files = models.FileField(upload_to= "video")
    price = models.FloatField(default=1.0)
    discount_price = models.FloatField(blank=True ,null=True)
    category = models.CharField(choices = CATEGORY_CHOICES , max_length =1)



    

    def get_add_to_cart_url(self):
        return reverse('core:add_cart', kwargs={
            'slug': self.slug
        })
        
    def get_absolute_url(self):
        return reverse('core:product', kwargs={
            'slug': self.slug
        })

    def get_remove_to_single_cart_url(self):
        return reverse('core:remove_single_cart', kwargs={
            'slug': self.slug
        })
       
    def get_remove_cart(self):
        return reverse('core:remove_cart' ,kwargs={
            'slug':self.slug
        })


 

class OrderItem(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.CASCADE)
    ordered = models.BooleanField(default=False)
    item =  models.ForeignKey(Videos,on_delete=models.CASCADE)
    quantity = models.IntegerField(default=1)

    def __str_(self):
        return f"{self.quantity} of {self.item.title}"
    def get_total_price(self):
        return self.item.price * self.quantity

  
class Order(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.CASCADE)
    items = models.ManyToManyField(OrderItem)
    start_date = models.DateTimeField(auto_now_add=True )
    order_date = models.DateField()
    ordered = models.BooleanField(default=False)
    def get_total(self):
        total = 0
        for item in self.items.all():
            total += item.get_total_price()
        return total


class Comment(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.CASCADE)
    post_id = models.ForeignKey(Videos ,on_delete=models.CASCADE)
    message = models.TextField('Message')
    comment_date = models.DateTimeField(auto_now=True)

class Address(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL,on_delete=models.CASCADE)
    name = models.CharField(max_length =15 )
    street_address = models.CharField(max_length= 30)
    zip_code = models.CharField(max_length = 10)
    coountry = CountryField(multiple=False)


    





    



