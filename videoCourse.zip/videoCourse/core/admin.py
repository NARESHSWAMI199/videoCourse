from django.contrib import admin
from .models import Videos,OrderItem,Order,Comment,Address


admin.site.register(Videos)
admin.site.register(OrderItem)
admin.site.register(Order)
admin.site.register(Comment)
admin.site.register(Address)

