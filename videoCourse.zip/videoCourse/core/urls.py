from django.urls import path,include
from . import views

app_name = 'core'
urlpatterns = [

    path("",views.HomeView.as_view(),name= "home"),
    path('add_cart/<slug>/', views.add_cart , name='add_cart'),
    path('remove_cart/<slug>/', views.remove_cart, name='remove_cart'),
    path('product/<slug>/',views.ItemDetailView,name='product'),
    path('python/',views.python,name='python'),
    path('java/',views.java,name='java'),
    path('kotlin/',views.kotlin,name='kotlin'),
    path('checkout/',views.checkout,name='checkout'),
    path('order-summary/',views.OrderSummary.as_view(),name='order-summary'),
    path('remove_single_cart/<slug>/',views.remove_single_cart , name="remove_single_cart"),
    

]