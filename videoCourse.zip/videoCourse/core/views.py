from django.shortcuts import render , get_object_or_404
from .models import Videos ,OrderItem,Order,Comment,Address
from django.contrib import  messages
from django.utils import timezone
from django.shortcuts import redirect
from .forms import CheckoutForm
from django.contrib.auth.decorators import login_required
from django.core.exceptions import ObjectDoesNotExist
from django.views.generic import DetailView,ListView,View
from django.contrib.auth.mixins import LoginRequiredMixin

class HomeView(ListView):
    model = Videos
    template_name = "home.html"



# class ItemDetailView(DetailView):
#     model = Videos
#     template_name = "detail.html"

@login_required
def ItemDetailView(request, slug):
    if request.method == 'POST':
        if request.POST['message']:
            comment = Comment()
            comment.message = request.POST['message']
            comment.user = request.user
            comment.post_id_id = slug
            comment.comment_date= timezone.datetime.now()
            comment.save()
        return redirect('core:product' ,slug=slug)
    
    items = Comment.objects.all().filter(post_id=slug)
    products = get_object_or_404(Videos, slug=slug)
    python = Videos.objects.all().filter(category='P')
    java = Videos.objects.all().filter(category='J' )
    kotlin = Videos.objects.all().filter(category='K' )
    return render(request ,'detail.html' , {'products' : products , 'items':items , 'playlists':python , 'java':java , 'kotlin':kotlin  })

def python(request):
    python = Videos.objects.all().filter(category='P')
    return render(request ,'python.html' , { 'playlists':python})
def java(request):
    java = Videos.objects.all().filter(category='J')
    return render(request ,'python.html' , { 'java':java})
def kotlin(request):
    kotlin= Videos.objects.all().filter(category='K')
    return render(request ,'python.html' , { 'kotlin':kotlin})
    

@login_required
def add_cart(request,slug):  
    item = get_object_or_404(Videos, slug=slug)
    order_item ,created = OrderItem.objects.get_or_create(
        item = item,
        user = request.user,
        ordered = False
    )
    order_qs = Order.objects.filter(user=request.user,ordered=False)
    if order_qs.exists():
        order = order_qs[0]
        #check item in this order
        if order.items.filter(item__slug = item.slug).exists():
            order_item.quantity +=1
            order_item.save()
            messages.info(request , "item quantity successfully updated")
            return redirect('/')
        else:
            order.items.add(order_item)
            messages.info(request ,"this item added in your cart")
            return redirect('/')
    else:
        order_date = timezone.now()
        order = Order.objects.create(user=request.user,order_date= order_date)
        order.item.add(order_item)
        return redirect('/')


@login_required   

def remove_single_cart(request, slug):
    item = get_object_or_404(Videos, slug=slug)
    order_qs =  Order.objects.filter(user=request.user, ordered = False)
    if order_qs.exists():
        order = order_qs[0]

        if order.items.filter(item__slug=item.slug).exists():
            order_item =OrderItem.objects.filter(
                item = item,
                user  = request.user,
                ordered  = False
            )[0]
            if order_item.quantity > 1:
                order_item.quantity  -= 1
                order_item.save()
            else :
                order.items.remove(order_item)
            messages.info(request,'this item added in your cart')
            return redirect('/')
    else:
        messages.info (request, 'sorry you have not any item in your cart')
        return redirect('/')
    return redirect('/')
        
def remove_cart(request,slug):
    item = get_object_or_404(Videos , slug=slug)
    order_qs = Order.objects.filter(
        user = request.user,
        ordered = False
    )

    if order_qs.exists():
        order = order_qs[0]
    #check if the orderItem in order
        if order.items.filter(item__slug = item.slug).exists():
            order_item = OrderItem.objects.filter(
                item = item,
                user = request.user,
                ordered = False
            )[0]
            order.items.remove(order_item)
            messages.info(request , "this item successfullly removed ")
            return redirect('/')
        else:
            messages.info(request , "this item not in your cart ")
            return redirect('core:product', slug=slug)
        messages.info(request , "you don't have a active order")
        return redirect('core:product' ,slug=slug)

@login_required
            
def checkout(request):     
        try:
            form  = CheckoutForm(request.POST) 
            if form.is_valid():
                name = request.POST.get('name' , '')
                street_address = request.POST.get('street_address' , '')
                zip_code = request.POST.get('zip_code' , ' ')
                country = request.POST.get('country',''), 


                Addres =  Address(
                user = request.user,
                name = name,
                street_address = street_address,
                zip_code = zip_code,
                coountry = country,
                )
                
                Addres.save()

                messages.success(request , 'successfully submited')
                return redirect('/')
            
                
            context = {
                'form' : form
            }
           
        except ObjectDoesNotExist:
            messages.info(request, "sorry not a valid form")
            return redirect ('/')
        return render(request, 'checkout.html' , context)

      

class OrderSummary(LoginRequiredMixin,View):
    def get(self,*args,**kwargs):
        try:
            order = Order.objects.get(user=self.request.user , ordered = False)
            context = {
                'order' : order
            }
            return render(self.request , 'order-summary.html' , context)
        except ObjectDoesNotExist:
            messages.info(self.request , 'sorry now you do not any active order ')
            return redirect('/')

